#grupop4

# Coordenador
- [[Evandro Fiorin]]
# Pesquisador externo ao grupo P4
Hélio Hirao

# Pesquisadores vinculados a Programas de Pós Graduação (Ativos)
- [[Arthur Fracaro Gonçalves]]
- [[Djonathan Freitas]]
- [[Igor Augusto de March]]
- [[Kauê Marques Romão]]
- [[Lais da Silva Rodrigues]]
- [[Lucas Rodrigo Nora]]
- [[Mariana Mamedes dos Santos]]
- [[Marina Biazotto Frascareli]]
- [[Rafael Marcos Zatta Krahl]]
- [[Vinicius Pauli]]

# Pesquisadores vinculados a Programas de Pós Graduação (Egressos)
- [[Amarildo Marcos Soares Junior]]
- [[Clara Troncoso Mello]]
- [[Guilherme do Carmo Gomes Dias]]
- [[Heber Macel Tenório Vasconcelos]]
- [[Kellen Melo Dorileo Louzich]]
- [[Lucas do Nascimento Souza]]
- [[Juliana Artuso]]
- [[Matheus Alcântara Silva Chaparim]]
