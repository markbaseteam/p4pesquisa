#locaisdepesquisa 

# Trabalhos
a

# Pesquisador
- [[Heber Macel Tenório Vasconcelos]]