#locaisdepesquisa 

# Trabalhos

- Amarildo Marcos Soares Junior. **O Rio de Janeiro pela experiência de Frederico Morais**. Início: 2020. Dissertação (Mestrado em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina, Coordenação de Aperfeiçoamento de Pessoal de Nível Superior.

# Pesquisador
- [[Amarildo Marcos Soares Junior]]