#locaisdepesquisa 

# Cidades
[[Araraquara - SP]]
[[Candido Mota - SP]]
[[São Carlos - SP]]