#locaisdepesquisa 

# Trabalhos
- pesquisa

# Pesquisador
[[Kauê Marques Romão]]
