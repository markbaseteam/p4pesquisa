#locaisdepesquisa 

# Trabalhos
- Aventuras de Arquiteto ao longo do antigo leito férreo de Bauru: o caminhar como modalidade de pesquisa. 
# Pesquisador
- [[Lucas do Nascimento Souza]]