#projetosdepesquisa 

# Ano
[[2021]]-Atual
# Apresentação
a
# Integrantes
 - [[Evandro Fiorin]] - Coordenador
 - Juliana Artuso
 - Maria Jose Luluaga Medici - Integrante
 - [[Djonathan Freitas]] - Integrante
 - [[Kellen Melo Dorileo Louzich]] - Integrante
 - [[Heber Macel Tenório Vasconcelos]] - Integrante
 - [[Lucas do Nascimento Souza]] - Integrante
 - [[Igor Augusto de March]] - Integrante
 - Clara Troncoso Mello - Integrante
 - Tiago Mitsuo Nagasaki - Integrante
 - [[Arthur Fracaro Gonçalves]] - Integrante
 - [[Mariana Mamedes dos Santos]] - Integrante
 - [[Lais da Silva Rodrigues]] - Integrante
 - [[Amarildo Marcos Soares Junior]] - Integrante
 