# Ano
2022

# Pesquisador
- [[Evandro Fiorin]]
- [[Arthur Fracaro Gonçalves]]
- [[Igor Augusto de March]]
- [[Juliana Artuso]]
