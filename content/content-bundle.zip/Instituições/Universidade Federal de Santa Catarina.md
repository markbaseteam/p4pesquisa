#universidade #santacatarina 

# Trabalhos
a

# Pesquisadores
- [[Arthur Fracaro Gonçalves]]
- [[Djonathan Freitas]]
- [[Igor Augusto de March]]
- [[Kauê Marques Romão]]
- [[Lucas Rodrigo Nora]]
- [[Rafael Marcos Zatta Krahl]]
- [[Vinicius Pauli]]
- [[Amarildo Marcos Soares Junior]]
- [[Kellen Melo Dorileo Louzich]]
- [[Matheus José Rigon]]