#universidade #sãopaulo 

# Trabalhos
- Ourinhos história e patrimônio ferroviário e industrial
- Araraquara história e patrimônio ferroviário e industrial
# Pesquisadores
- [[Lais da Silva Rodrigues]]
- [[Mariana Mamedes dos Santos]]
- [[Marina Biazotto Frascareli]]
- [[Lucas do Nascimento Souza]]