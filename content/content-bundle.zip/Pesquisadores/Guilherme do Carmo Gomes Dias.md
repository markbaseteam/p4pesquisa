#pesquisador #grupop4 #egresso 

# Nome
Guilherme do Carmo Gomes Dias
# Formação
Arquiteto e Urbanista (FCT-Unesp) - Pós-graduado em Habitação e Cidade pela Escola da Cidade - São Paulo - Mestre em Arquitetura e Urbanismo, área: 'Arquitectura Avanzada Paisaje Urbanismo y Diseño' pela (Universidad Politécnica de Valencia) com especialização em desenvolvimento urbano com base nos conceitos de habitat sustentável.
# Lattes
http://lattes.cnpq.br/4750573255398506
# Email e Contato
arq.gdias@gmail.com/ (17) 99661-5183
# Trabalhos

## Artigos completos publicados

FIORIN, Evandro. ; [DIAS, G. C. G.](http://lattes.cnpq.br/4750573255398506) . Caminhografias no Minhocão em São Paulo. CINCO PORCENTO ARQUITECTURA MAIS ARTE, v. 01, p. 1-21, 2020.

  

## Livros publicados

FIORIN, E. ; [DIAS, G. C. G.](http://lattes.cnpq.br/4750573255398506) ; FREITAS, D. ; VASCONCELOS, H. M. T. ; LOUZICH, K. M. D. ; RODRIGUES, L. S. ; SOUZA, L. N. ; CHAPARIM, M. A. S. ; POLLI, P. G. . A Cidade Inacabada. 1. ed. Tupã e Florianópolis: Anap e Arquitetura & Urbanismo/UFSC Publicações, 2021. v. 1. 194p .
