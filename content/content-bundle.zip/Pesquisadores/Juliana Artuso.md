#pesquisador #grupop4 #egresso 

# Nome
Juliana Artuso
# Formação
a
# Lattes
a
# Contato
a
# Trabalhos

## Capítulo em livro publicado

[FIORIN, E.](http://lattes.cnpq.br/5599203800231511); ARTUSO, J. . Experiências de Reconhecimento Urbano em São Paulo: Transurbanogramas do Minhocão. In: FIORIN, E.; HIRAO, H.. (Org.). Cartografias da Cidade. 1ed.Tupã-São Paulo: Anap, 2019, v. 1, p. 134-154.

  

## Trabalhos publicados em anais de congressos

[ARTUSO, J.](http://lattes.cnpq.br/9860093314995862); [FIORIN, E.](http://lattes.cnpq.br/5599203800231511) . Trans-Urbano-Gramas - Trajetos, Territórios e suas traduções: 'Experiências de reconhecimento urbano no Minhocão'. In: XI Congresso de Iniciação Científica do Curso de Arquitetura e Urbanismo CICAU, 2018, Presidente Prudente. Anais do XI CICAU, 2018.**