#pesquisador #grupop4 #santacatarina #ativo 

# Nome
Lucas Rodrigo Nora
# Lattes
http://lattes.cnpq.br/5224900327031264
# Email e contato
a
# Trabalhos

## Doutorado em andamento

Lucas Rodrigo Nora. Arquiteturas Abandonadas em Santa Catarina. Início: 2022. Tese (Doutorado em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina, Fundação de Amparo à Pesquisa e Inovação do Estado de Santa Catarina.