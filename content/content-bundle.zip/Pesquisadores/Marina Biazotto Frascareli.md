#pesquisador #grupop4 #ativo #sãopaulo  

# Nome
Marina Biazotto Frascareli
# Formação
a
# Lattes
http://lattes.cnpq.br/9344662967503617
# Email e Contato
mb.frascareli@unesp.br
# Trabalhos

## Mestrado em andamento 

Marina Biazotto Frascareli. São Carlos: patrimônio e marginalidade ao longo do antigo leito férreo. Início: 2022. Dissertação (Mestrado em Arquitetura e Urbanismo) - Universidade Estadual Paulista Júlio de Mesquita Filho.
