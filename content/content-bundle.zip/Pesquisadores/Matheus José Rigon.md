#pesquisador #grupop4 #egresso 

# Nome
Matheus José Rigon
# Formação
Arquiteto e Urbanista formado/ Universidade Comunitária da região de Chapecó - UNOCHAPECO. Mestre em Arquitetura e Urbanismo/ Universidade Federal de Santa Catarina - UFSC. Especialização em Arquitetura da Cidade/ Pontifícia Universidade Católica do Rio Grande do Sul - PUCRS.
# Lattes
http://lattes.cnpq.br/5047199203930798
# Contato
(54) 99681-6065
# Trabalhos
