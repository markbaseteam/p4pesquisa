#pesquisador #grupop4 #santacatarina #ativo 

# Nome
Arthur Fracaro Gonçalves
# Formação
Graduando em Arquitetura e Urbanismo/ Universidade Federal de Santa Catarina - UFSC. Bolsista de Iniciação Científica PIBIC-CNPq-UFSC.
# Lattes
[http://lattes.cnpq.br/9279268043381284](http://lattes.cnpq.br/9279268043381284)
# Email e Contato
**[arthurfracaro@hotmail.com](mailto:arthurfracaro@hotmail.com)/ (48) 99809-7368**
# Trabalhos
TransUrbanoGramas: experiências de reconhecimento urbano no centro expandido de Florianópolis. 
[[ebook Cidade Inacabada ANAP]]

## Iniciação científica

Arthur Fracaro Gonçalves. Florianópolis: entre grafites e lugares à margem. 2020. Iniciação Científica. (Graduando em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina, Conselho Nacional de Desenvolvimento Científico e Tecnológico. Orientador: Evandro Fiorin.
