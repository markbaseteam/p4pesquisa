#pesquisador #grupop4 #egresso #matogrosso

# Nome
Kellen Melo Dorileo Louzich
# Formação
Artista Plástica, Mestre em Arquitetura e Urbanismo/ Universidade Federal de Santa Catarina - UFSC. Arquiteta e Urbanista/ Universidade do Mato Grosso - UFMT
# Lattes
http://lattes.cnpq.br/1928482851339357
# Email e Contato
[kellendorileo@gmail.com](mailto:kellendorileo@gmail.com)/ (65) 98113-3621
# Trabalhos

## Capítulo de livro publicado

Louzich, Kellen Melo Dorileo ; FIORIN, EVANDRO . PERMANÊNCIAS E TRANSFORMAÇÕES DO CENTRO HISTÓRICO DE CUIABÁ: UMA CONSTRUÇÃO HISTORIOGRÁFICA.. In: Frederico C. Barbosa. (Org.). Permanências e Transformações do Centro Histórico de Cuiabá: uma construção historiográfica. 1ed.Goias: Conhecimento Livre, 2020, v. II, p. 94-114.

  

[VASCONCELOS, HEBER MACEL TENÓRIO](http://lattes.cnpq.br/1290805936456727). Um bairro que desliza: vazios inconclusos. A cidade inacabada. 1ed.São Paulo: ANAP, 2021, v. 1, p. 58-77.

  

## Trabalhos publicados em anais de congresso

[LOUZICH, K. M. D.](http://lattes.cnpq.br/1928482851339357) ; FIORIN, E. ; CORTES, M. L. . Arquitetura Cuiabana: permanências e transformações no centro histórico da cidade. In: CONGRESSO NACIONAL PARA SALVAGUARDA DO PATRIMÔNIO CULTURAL, 2019, Cachoeira do Sul. Anais [recurso eletrônico] do II Congresso Nacional para Salvaguarda do Patrimônio Cultural: as problemáticas da preservação do patrimônio cultural no século XXI: Anais : Volume III: Paisagem em suas várias dimensões, 11, 12, 13 e 14 de novembro de 2019 /. Cachoeira do Sul: UFSM-CS, 2019. v. 3. p. 97-110.

  

## Livros publicados

FIORIN, Evandro ; FREITAS, Djonathan. ; DIAS, Guilherme do Carmo Gomes ; VASCONCELOS, HEBER MACEL TENÓRIO ; LOUZICH, K. M. D. ; RODRIGUES, L. S. ; SOUZA, L. N. ; CHAPARIM, M. A. S. ; POLLI, Paula Gabbi . A cidade inacabada. 1. ed. São Paulo: ANAP, 2021. v. 1. 192p .

  

