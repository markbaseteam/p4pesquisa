#pesquisador #grupop4 #ativo #sãopaulo 

# Nome
Mariana Mamede dos Santos
# Formação
a
# Lattes
http://lattes.cnpq.br/0859887896743468
# Email e Contato
mamedesmariana@gmail.com
# Trabalhos

## Capítulo de livros publicados

[FIORIN, E.](http://lattes.cnpq.br/5599203800231511); SANTOS, M. M. . Patrimônio Ferroviário e Industrial de Ourinhos (SP): história e preservação. In: Jefferson Oliveira Goulart; Norma Regina Truppel Constantino (orgs). (Org.). Pesquisa em Arquitetura e Urbanismo ? as cidades e seus desafios [vol. 6]. 1ed.Tupã-SP: ANAP, 2021, v. 1, p. 1-.

  

## Trabalhos completos publicados em anais de congresso

SANTOS, M. M. ; FIORIN, E. ; RODRIGUES, L. S. . Ourinhos: história e patrimônio ferroviário e industrial. In: XVI Fórum Ambiental da AltaPaulista, 2020, Tupã-São Paulo. ANAIS XVI Fórum Ambiental da Alta Paulista. Tupã: Anap, 2020. v. 1. p. 1292-1301.

  

## Resumos publicados em anais de congresso 

[SANTOS, M. M.](http://lattes.cnpq.br/0859887896743468). A descaracterização de centros históricos no interior paulista. In: II Simpósio Científico do ICOMOS Brasil, 2018, Belo Horizonte. Anais do II Simpósio Científico ICOMOS. Belo Horizonte: Universidade Federal de Minas Gerais, 2018. v. I. p. 3216-3235.

  

## Mestrado em andamento

Mariana Mamedes dos Santos. Patrimônio e Marginalidade ao longo do antigo leito férreo de Ourinhos-SP. Início: 2020. Dissertação (Mestrado em Arquitetura e Urbanismo) - Universidade Estadual Paulista Júlio de Mesquita Filho.

**