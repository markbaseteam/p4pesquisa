#pesquisador #grupop4 #egresso #riodejaneiro

# Nome
Amarildo Marcos Soares Junior
# Formação
a
# Lattes
http://lattes.cnpq.br/7207639678848227
# Email e Contato
a
# Trabalhos

## Mestrado 

Amarildo Marcos Soares Junior. O Rio de Janeiro pela experiência de Frederico Morais. Início: 2020. Dissertação (Mestrado em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina, Coordenação de Aperfeiçoamento de Pessoal de Nível Superior.
