#pesquisador #grupop4 #ativo #sãopaulo

# Nome
Kauê Marques Romão
# Formação
Arquitetura-Urbanismo (Universidade Paulista - UNIP) | Técnico em Edificações (ETEC Dra. Ruth Cardoso)
# Lattes
http://lattes.cnpq.br/9200565420988518
# Email e Contato
[marquees.kaue@gmail.com](mailto:marquees.kaue@gmail.com) | (13) 98229-3398
# Trabalhos

## Mestrado em andamento

Kauê Marques Romão. Marginalidade ao longo do antigo leito férreo de São Vicente-SP. Inicio: 2022. Dissertação (Mestrado em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina.