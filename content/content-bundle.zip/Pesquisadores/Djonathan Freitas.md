#pesquisador #grupop4 #ativo
#santacatarina

# Nome
Djonathan Freitas
# Formação
Arquiteto e Urbanista/ Universidade do Estado de Santa Catarina - UDESC/Ceres.
# Lattes
http://lattes.cnpq.br/4936423096733548
# Email e Contato
[freitas_djonathan@hotmail.com](mailto:freitas_djonathan@hotmail.com)/ (47) 99639-0649
# Trabalhos


## Mestrado em andamento 

Djonathan Freitas. A Ruína como lugar de resistência na Grande Florianópolis-SC. Início: 2020. Dissertação (Mestrado profissional em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina, Coordenação de Aperfeiçoamento de Pessoal de Nível Superior. 

  

## Capítulo de livros publicados

FIORIN, E ; FREITAS, D. ; DIAS, G. C. G. ; VASCONCELOS, H. M. T. ; LOUZICH, K. M. D. ; RODRIGUES, L. S. ; SOUZA, L. N. ; CHAPARIM, M. A. S. ; PAOLLI, P. G. . A cidade Inacabada. 1. ed. São Paulo: ANAP, 2021. v. 1. 194p .

  

## Resumo expandido em anais de congressos

[FREITAS, djonathan](http://lattes.cnpq.br/4936423096733548). Caminho das Ruínas: Retratos do abandono na arquitetura de Florianópolis.. In: 3º Simpósio Científico do ICOMOS Brasil, 2019, Belo Horizonte. Anais do 3º Simpósio Científico do ICOMOS Brasil. Belo Horizonte: Even3, 2019.**