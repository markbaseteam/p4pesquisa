#pesquisador #grupop4 #santacatarina #ativo 

# Nome
Vinicius Pauli
# Formação
Graduando em Arquitetura e Urbanismo pela Universidade Federal de Santa Catarina.
# Lattes
http://lattes.cnpq.br/0524051648561557
# Email e Contato
[vinicius.pauli99@gmail.com](mailto:vinicius.pauli99@gmail.com)/ (48) 99981-9270
# Trabalhos

## Iniciação científica 

Vinicius Pauli. Intervenções Projetuais em Lugares à Margem. Início: 2021. Iniciação científica (Graduando em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina, Conselho Nacional de Desenvolvimento Científico e Tecnológico. (Orientador).
