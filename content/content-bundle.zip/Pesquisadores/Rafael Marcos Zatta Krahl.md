#pesquisador #grupop4 #ativo #santacatarina  

# Nome
Rafael Marcos Zatta Krahl
# Formação
Especialista em Ferramentas de Gestão e Projetos BIM (IPOG Florianópolis-SC) | Arquiteto-urbanista (Centro Universitário Unifacvest Lages-SC) | Técnico em Edificações (CEDUP Renato Ramos da Silva Lages-SC)
# Lattes
[http://lattes.cnpq.br/2200330037247256](http://lattes.cnpq.br/2200330037247256)
# Email e Contato
[rafaelkrahl@gmail.com](mailto:rafaelkrahl@gmail.com) | (49) 99906-7000
# Trabalhos

## Mestrado em andamento

Rafael Marcos Zatta Krahl. O projeto inconcluso e a cultura arquitetônica do sul do Brasil. Início: 2022. Dissertação (Mestrado em Arquitetura e Urbanismo) - Universidade Federal de Santa Catarina.
