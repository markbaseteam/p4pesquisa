#pesquisador #grupop4 #santacatarina #ativo 

# Nome
Igor Augusto de March
# Formação
Graduando em Arquitetura e Urbanista/ Universidade Federal de Santa Catarina - UFSC. Bolsista de Iniciação Científica PIBIC-CNPq-UFSC
# Lattes
http://lattes.cnpq.br/2483094827584327
# Email e Contato
[igordemarch@hotmail.com](mailto:igordemarch@hotmail.com)/ (48) 99915-2610
# Trabalhos

## Capítulos de livros publicados 

[FIORIN, E.](http://lattes.cnpq.br/5599203800231511); MARCH, I. A. . Transurbanogramas: caminhar e cartografar na capital catarinense.. In: NUNES, L. A.; SCHWARTZ, R. M. P. B. (org).. (Org.). Entre Territórios e Redes: arte, memórias, cidades.. 1ed.São Paulo: Manuscrito, 2022, v. 1, p. 108-123.