#pesquisador #grupop4 #egresso 

# Nome
Matheus Alcantara Silva Chaparim
# Formação
a
# Lattes
[http://lattes.cnpq.br/3733094266035366](http://lattes.cnpq.br/3733094266035366)
# Email e Contato
a
# Trabalhos

## Livros publicados 

FIORIN, E. ; FREITAS, D. ; DIAS, G. C. G. ; VASCONCELOS, H. M. T. ; LOUZICH, K. M. D. ; RODRIGUES, L. S. ; SOUZA, L. N. ; CHAPARIM, M. A. S. ; POLLI, P. G. . A cidade inacabada. 1. ed. Tupã: ANAP, 2021.

## Capítulos de livros publicados

[CHAPARIM, MATHEUS A. S.](http://lattes.cnpq.br/3733094266035366); HIRAO, HÉLIO . A Deriva como Processo de Reconhecimento do Patrimônio Industrial de Sevilha. In: Evandro Fiorin; Hélio Hirao. (Org.). Cartografias da Cidade. 1ed.Tupã: Editora ANAP, 2019, v. 1, p. 72-93.

## Transcrições

Entrevista com Francesco Careri. A Internacional Situacionista e as derivas contemporâneas. Entrevistadores: Matheus Alcântara Silva Chaparim e Paulina Maria Caon. In: RISCO REVISTA DE PESQUISA EM ARQUITETURA E URBANISMO. São Carlos: Instituto de Arquitetura e Urbanismo da Universidade de São Paulo (IAU-USP), 2022. Anual. v. 20. p.255. ISSN 1984-4506. Disponível em: https://www.revistas.usp.br/risco/issue/view/12491/2293.**